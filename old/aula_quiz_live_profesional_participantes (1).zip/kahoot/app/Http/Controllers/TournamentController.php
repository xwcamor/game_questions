<?php
namespace App\Http\Controllers;
use App\Models\Tournament; use Illuminate\Http\Request;
class TournamentController extends Controller {
 public function index(Request $r){$tournaments=Tournament::withCount('sessions')->where('owner_id',$r->user()->id)->latest()->get();return view('admin.tournaments',compact('tournaments'));}
 public function store(Request $r){$data=$r->validate(['name'=>['required','string','max:150'],'description'=>['nullable','string','max:2000'],'starts_at'=>['nullable','date']]);$r->user()->tournaments()->create($data+['status'=>'planned']);return back()->with('success','Torneo creado.');}
}
