<?php
namespace App\Http\Controllers;
use App\Models\Student; use Illuminate\Http\Request; use Illuminate\Validation\Rule;
class StudentController extends Controller {
 public function index(Request $r){$students=Student::where('owner_id',$r->user()->id)->orderBy('name')->paginate(15);return view('admin.participants',compact('students'));}
 public function store(Request $r){$data=$r->validate(['student_code'=>['required','string','max:40',Rule::unique('students')->where(fn($q)=>$q->where('owner_id',$r->user()->id))],'name'=>['required','string','max:120'],'email'=>['nullable','email','max:255'],'group_name'=>['nullable','string','max:100']]);$r->user()->students()->create($data);return back()->with('success','Participante registrado correctamente.');}
 public function update(Request $r,Student $student){abort_unless($student->owner_id===$r->user()->id,404);$data=$r->validate(['student_code'=>['required','string','max:40',Rule::unique('students')->where(fn($q)=>$q->where('owner_id',$r->user()->id))->ignore($student->id)],'name'=>['required','string','max:120'],'email'=>['nullable','email','max:255'],'group_name'=>['nullable','string','max:100'],'is_active'=>['nullable','boolean']]);$student->update($data+['is_active'=>$r->boolean('is_active')]);return back()->with('success','Participante actualizado.');}
 public function destroy(Request $r,Student $student){abort_unless($student->owner_id===$r->user()->id,404);$student->delete();return back()->with('success','Participante eliminado del padrón.');}
}
