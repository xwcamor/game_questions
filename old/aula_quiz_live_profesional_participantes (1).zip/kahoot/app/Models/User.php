<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable; use Illuminate\Notifications\Notifiable; use Illuminate\Database\Eloquent\Relations\HasMany;
class User extends Authenticatable { use Notifiable; protected $fillable=['name','email','password']; protected $hidden=['password','remember_token']; protected function casts(): array{return ['email_verified_at'=>'datetime','password'=>'hashed'];} public function quizzes(): HasMany{return $this->hasMany(Quiz::class,'owner_id');} public function tournaments(): HasMany{return $this->hasMany(Tournament::class,'owner_id');} public function students(): HasMany{return $this->hasMany(Student::class,'owner_id');} }
