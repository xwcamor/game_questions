<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model; use Illuminate\Database\Eloquent\Relations\BelongsTo; use Illuminate\Database\Eloquent\Relations\HasMany;
class Quiz extends Model { protected $fillable=['owner_id','title','description','is_published']; protected function casts(): array{return ['is_published'=>'boolean'];} public function owner(): BelongsTo{return $this->belongsTo(User::class,'owner_id');} public function questions(): HasMany{return $this->hasMany(Question::class)->orderBy('position');} public function sessions(): HasMany{return $this->hasMany(GameSession::class);} }
