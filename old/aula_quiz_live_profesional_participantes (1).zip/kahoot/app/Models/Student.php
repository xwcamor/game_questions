<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model; use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Student extends Model { protected $fillable=['owner_id','student_code','name','email','group_name','is_active']; protected function casts(): array{return ['is_active'=>'boolean'];} public function owner(): BelongsTo{return $this->belongsTo(User::class,'owner_id');} }
