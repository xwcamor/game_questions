<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model; use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Answer extends Model { protected $fillable=['game_session_id','participant_id','question_id','question_option_id','is_correct','response_ms','points','answer_order','answered_at']; protected function casts(): array{return ['is_correct'=>'boolean','answered_at'=>'datetime'];} public function participant(): BelongsTo{return $this->belongsTo(Participant::class);} public function option(): BelongsTo{return $this->belongsTo(QuestionOption::class,'question_option_id');} }
