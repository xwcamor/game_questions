<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model; use Illuminate\Database\Eloquent\Relations\BelongsTo; use Illuminate\Database\Eloquent\Relations\HasMany;
class Tournament extends Model { protected $fillable=['owner_id','name','description','starts_at','status']; protected function casts(): array{return ['starts_at'=>'datetime'];} public function owner(): BelongsTo{return $this->belongsTo(User::class,'owner_id');} public function sessions(): HasMany{return $this->hasMany(GameSession::class);} }
