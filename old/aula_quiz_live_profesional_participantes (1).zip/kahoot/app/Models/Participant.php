<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model; use Illuminate\Database\Eloquent\Relations\BelongsTo; use Illuminate\Database\Eloquent\Relations\HasMany;
class Participant extends Model { protected $fillable=['game_session_id','student_id','nickname','token_hash','score','joined_at','last_seen_at']; protected function casts(): array{return ['joined_at'=>'datetime','last_seen_at'=>'datetime'];} public function gameSession(): BelongsTo{return $this->belongsTo(GameSession::class);} public function answers(): HasMany{return $this->hasMany(Answer::class);} }
