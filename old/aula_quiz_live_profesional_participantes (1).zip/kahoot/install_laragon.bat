@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo       AULA QUIZ LIVE - INSTALADOR
echo ==========================================
where php >nul 2>nul
if errorlevel 1 (
  echo ERROR: PHP no esta en PATH. Abre la Terminal de Laragon.
  pause
  exit /b 1
)
where composer >nul 2>nul
if errorlevel 1 (
  echo ERROR: Composer no esta en PATH. Abre la Terminal de Laragon.
  pause
  exit /b 1
)
if not exist bootstrap\cache mkdir bootstrap\cache
if not exist storage\framework\cache\data mkdir storage\framework\cache\data
if not exist storage\framework\sessions mkdir storage\framework\sessions
if not exist storage\framework\views mkdir storage\framework\views
if not exist storage\logs mkdir storage\logs
if not exist .env (
  copy .env.example .env >nul
  echo Se creo .env desde .env.example
)
echo.
echo [1/4] Instalando dependencias PHP...
composer install --no-interaction
if errorlevel 1 goto error
echo.
echo [2/4] Generando clave de aplicacion...
php artisan key:generate
if errorlevel 1 goto error
echo.
echo [3/4] Limpiando caches...
php artisan optimize:clear
if errorlevel 1 goto error
echo.
echo [4/4] Listo. Verifica la conexion MySQL en .env.
echo IMPORTANTE: primero importa database\aula_quiz_live_unico.sql en phpMyAdmin.
echo No ejecutes migrate --seed si ya importaste ese SQL.
echo.
echo Para iniciar, ejecuta start_laragon.bat o php artisan serve --host=0.0.0.0 --port=8000
pause
exit /b 0
:error
echo.
echo Hubo un error. Revisa el mensaje anterior y el README.md.
pause
exit /b 1
