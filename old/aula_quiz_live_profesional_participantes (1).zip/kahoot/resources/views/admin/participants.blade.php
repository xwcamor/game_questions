@extends('layouts.app')
@section('title','Participantes · Aula Quiz Live')
@section('body')
<div class="app-shell">
 <aside class="sidebar">
  <a class="brand" href="{{ route('admin.quizzes') }}"><span class="brand-mark small">AQ</span><span>Aula Quiz <b>Live</b></span></a>
  <div class="side-label">GESTIÓN ACADÉMICA</div>
  <a class="nav-item" href="{{ route('admin.quizzes') }}">▦ <span>Cuestionarios</span></a>
  <a class="nav-item active" href="{{ route('admin.participants') }}">♙ <span>Participantes</span></a>
  <a class="nav-item" href="{{ route('admin.tournaments') }}">♜ <span>Torneos</span></a>
  <div class="side-bottom"><div class="avatar">{{ strtoupper(substr(auth()->user()->name,0,1)) }}</div><div class="user-mini"><b>{{ auth()->user()->name }}</b><small>Docente</small></div><form method="POST" action="{{ route('logout') }}">@csrf<button class="logout">↗</button></form></div>
 </aside>
 <main class="main-area">
  <header class="topbar"><div><span class="eyebrow">GESTIÓN DE ALUMNOS</span><h1>Participantes</h1><p class="muted">Administra el padrón que tus alumnos utilizarán para identificarse al entrar a una partida.</p></div></header>
  @if(session('success'))<div class="success">{{ session('success') }}</div>@endif
  @if($errors->any())<div class="alert">{{ $errors->first() }}</div>@endif
  <div class="participants-layout">
   <section class="panel participant-form"><div class="panel-heading"><div><span class="eyebrow">NUEVO REGISTRO</span><h2>Agregar participante</h2><p class="muted">El código será solicitado al ingresar a una sala.</p></div></div>
    <form method="POST" action="{{ route('admin.participants.store') }}">@csrf
     <label>Código de participante</label><input name="student_code" required maxlength="40" placeholder="Ej. ALU-001" value="{{ old('student_code') }}">
     <label>Nombre completo</label><input name="name" required maxlength="120" placeholder="Nombre y apellidos" value="{{ old('name') }}">
     <label>Correo electrónico <small>Opcional</small></label><input type="email" name="email" placeholder="alumno@correo.com" value="{{ old('email') }}">
     <label>Curso / sección <small>Opcional</small></label><input name="group_name" maxlength="100" placeholder="Ej. Redes - Sección A" value="{{ old('group_name') }}">
     <button class="btn btn-primary full">Registrar participante</button>
    </form>
   </section>
   <section class="participants-list"><div class="section-head"><div><h2>Padrón de participantes</h2><p class="muted">{{ $students->total() }} registro(s)</p></div></div>
    <div class="table-wrap"><table class="data-table"><thead><tr><th>Código</th><th>Nombre</th><th>Curso / sección</th><th>Estado</th><th></th></tr></thead><tbody>
    @forelse($students as $student)<tr><td><span class="code-chip">{{ $student->student_code }}</span></td><td><strong>{{ $student->name }}</strong><small>{{ $student->email ?: 'Sin correo registrado' }}</small></td><td>{{ $student->group_name ?: '—' }}</td><td><span class="status-pill {{ $student->is_active?'':'inactive' }}">{{ $student->is_active?'Activo':'Inactivo' }}</span></td><td><form method="POST" action="{{ route('admin.participants.destroy',$student) }}" onsubmit="return confirm('¿Eliminar este participante del padrón?')">@csrf @method('DELETE')<button class="text-action danger">Eliminar</button></form></td></tr>
    @empty<tr><td colspan="5" class="table-empty">Todavía no hay participantes registrados. Agrega el primero desde el formulario.</td></tr>@endforelse
    </tbody></table></div>{{ $students->links() }}
   </section>
  </div>
  <footer>AULA QUIZ LIVE <span>·</span> Administración de participantes</footer>
 </main>
</div>
@endsection
