@extends('layouts.app') @section('title','Unirse a partida · Aula Quiz Live') @section('body')
<main class="player-shell"><div class="player-card"><div class="brand-mark">AQ</div><span class="eyebrow">ÚNETE A LA PARTIDA</span><h1>Aula Quiz <span>Live</span></h1><div class="player-pin">{{ $game->pin }}</div><p class="muted">{{ $game->quiz->title }}</p>@if($errors->any())<div class="alert">{{ $errors->first() }}</div>@endif
@if($game->status!=='lobby')<div class="alert">Esta partida ya comenzó. Pide al docente que inicie una nueva sala.</div>@else
<form method="POST" action="{{ route('player.join.post',$game->pin) }}">@csrf<label>Código de participante <small>(si estás registrado)</small></label><input class="wide-input" name="student_code" maxlength="40" placeholder="Ej. ALU-001"><div class="join-divider">O ingresa como invitado</div><label>Tu nombre o apodo</label><input class="wide-input" name="nickname" maxlength="40" minlength="2" autofocus placeholder="¿Cómo te llamas?"><button class="btn btn-primary full">Entrar a la partida →</button></form>
@endif<div class="hint">No necesitas crear una cuenta para participar.</div></div></main>
@endsection
