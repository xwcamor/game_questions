<?php
namespace Database\Seeders;
use App\Models\User; use App\Models\Quiz; use Illuminate\Database\Seeder; use Illuminate\Support\Facades\Hash;
class DatabaseSeeder extends Seeder { public function run(): void {
 $user=User::firstOrCreate(['email'=>'docente@aula.test'],['name'=>'Docente Demo','password'=>Hash::make('AulaQuiz2026!')]);
 if($user->quizzes()->exists()) return;
 $bank=json_decode(file_get_contents(database_path('seeders/questions-sistemas-operativos.json')),true);
 $quiz=$user->quizzes()->create(['title'=>'Sistemas Operativos y Comunicación de Datos','description'=>'Banco inicial importado de la evaluación de 40 preguntas. Puedes editarlo desde el panel.']);
 foreach($bank as $i=>$item){$q=$quiz->questions()->create(['position'=>$i+1,'prompt'=>$item['q'],'time_limit'=>20]);foreach(array_slice($item['a'],0,4) as $j=>$text){$q->options()->create(['position'=>$j+1,'text'=>$text,'is_correct'=>$j===(int)$item['k']]);}}
 $user->tournaments()->create(['name'=>'Torneo de práctica','description'=>'Torneo inicial de demostración','status'=>'planned']);
} }
