<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void {
 Schema::create('quizzes', function(Blueprint $t){$t->id();$t->foreignId('owner_id')->constrained('users')->cascadeOnDelete();$t->string('title');$t->text('description')->nullable();$t->boolean('is_published')->default(true);$t->timestamps();});
 Schema::create('questions', function(Blueprint $t){$t->id();$t->foreignId('quiz_id')->constrained()->cascadeOnDelete();$t->unsignedInteger('position');$t->text('prompt');$t->unsignedSmallInteger('time_limit')->default(20);$t->timestamps();$t->unique(['quiz_id','position']);});
 Schema::create('question_options', function(Blueprint $t){$t->id();$t->foreignId('question_id')->constrained()->cascadeOnDelete();$t->unsignedTinyInteger('position');$t->string('text',500);$t->boolean('is_correct')->default(false);$t->timestamps();$t->unique(['question_id','position']);});
 Schema::create('tournaments', function(Blueprint $t){$t->id();$t->foreignId('owner_id')->constrained('users')->cascadeOnDelete();$t->string('name');$t->text('description')->nullable();$t->dateTime('starts_at')->nullable();$t->string('status')->default('planned');$t->timestamps();});
 } public function down(): void { Schema::dropIfExists('tournaments');Schema::dropIfExists('question_options');Schema::dropIfExists('questions');Schema::dropIfExists('quizzes'); } };
