<?php
use Illuminate\Support\Facades\Artisan;
Artisan::command('about-quiz', function () { $this->info('Aula Quiz Live listo para jugar.'); });
