# Aula Quiz Live

Plataforma web de cuestionarios competitivos inspirada en la dinámica de Kahoot, preparada para ejecutarse localmente con Laragon en Windows.

## Qué incluye esta versión

- Panel de docente con inicio de sesión.
- Creación, edición y eliminación de cuestionarios.
- Preguntas con cuatro alternativas, respuesta correcta y tiempo configurable.
- Banco inicial de 40 preguntas de **Sistemas Operativos y Comunicación de Datos**.
- Padrón de participantes: alta, listado y eliminación de alumnos con código, nombre, correo y curso/sección.
- Identificación de alumnos registrados al ingresar a una sala mediante su código; también se permite el acceso como invitado.
- Creación de torneos y asociación de una partida a un torneo.
- Salas de juego con PIN de seis dígitos.
- Ingreso de participantes desde celular o computadora mediante PIN y apodo.
- Inicio de partida desde la pantalla del docente.
- Respuestas de los participantes y registro de orden de llegada en el servidor.
- Puntaje por respuesta correcta y rapidez.
- Revelación de respuesta correcta, ranking y podio.
- Diseño adaptable a pantallas de escritorio y móviles.

## Tecnologías y requisitos

- Laravel 13.
- PHP 8.3 o superior (tu PHP 8.3.33 cumple este requisito).
- Composer 2.
- MySQL 8 o MariaDB compatible.
- Laragon para el entorno local.
- No requiere Node.js ni `npm install`; los recursos del frontend ya están incluidos.

La sincronización de la partida se realiza mediante consultas periódicas al servidor (polling). Esta entrega no utiliza WebSockets todavía. El panel incorpora una sección Participantes para mantener el padrón de alumnos. Cada alumno puede entrar con su código registrado o como invitado con un apodo.

## Instalación desde cero en Laragon

> Sigue este orden. El ZIP incluye **un solo SQL oficial** para crear la base y cargar los datos iniciales.

### 1. Descomprimir

Descomprime la carpeta `kahoot` en:

```text
C:\laragon\www\kahoot
```

Si Windows crea una carpeta anidada (por ejemplo `kahoot\kahoot`), mueve el contenido interno para que `artisan`, `composer.json` y `README.md` queden directamente dentro de `C:\laragon\www\kahoot`.

### 2. Importar la base de datos única

1. Abre Laragon y enciende **MySQL**.
2. Abre phpMyAdmin.
3. Entra a **Importar**.
4. Selecciona:

```text
database\aula_quiz_live_unico.sql
```

5. Ejecuta la importación.

El SQL crea la base `quiz_live`, sus tablas (incluido el padrón `students` y su relación con los participantes de cada partida), el registro de migraciones, el usuario docente y el cuestionario inicial con sus 40 preguntas.

**Advertencia:** este SQL elimina y vuelve a crear las tablas incluidas. Úsalo únicamente para una instalación nueva o cuando quieras reiniciar los datos. No lo importes encima de información que quieras conservar.

### 3. Instalar Laravel

Abre la **Terminal de Laragon** y ejecuta:

```bat
cd C:\laragon\www\kahoot
install_laragon.bat
```

El instalador crea las carpetas de caché y almacenamiento que Laravel necesita, instala dependencias con Composer, crea `.env` si no existe, genera `APP_KEY` y limpia las cachés.

También puedes ejecutar los comandos manualmente:

```bat
cd C:\laragon\www\kahoot
mkdir bootstrap\cache
mkdir storage\framework\cache\data
mkdir storage\framework\sessions
mkdir storage\framework\views
mkdir storage\logs
composer install
copy .env.example .env
php artisan key:generate
php artisan optimize:clear
```

Si `.env` ya existe, no lo sobrescribas con `copy`.

### 4. Revisar conexión MySQL

Abre el archivo `.env` y verifica estos valores (ajústalos si tu MySQL usa otra contraseña o puerto):

```env
APP_NAME="Aula Quiz Live"
APP_ENV=local
APP_DEBUG=true
APP_URL=http://127.0.0.1:8000

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=quiz_live
DB_USERNAME=root
DB_PASSWORD=
```

Guarda los cambios y ejecuta:

```bat
php artisan optimize:clear
```

### 5. Iniciar la plataforma

Desde la terminal de Laragon:

```bat
php artisan serve --host=0.0.0.0 --port=8000
```

O ejecuta `start_laragon.bat`.

Abre en la computadora del docente:

```text
http://127.0.0.1:8000
```

Para que los alumnos entren desde celulares conectados a la misma red Wi-Fi, averigua la IPv4 de la PC docente con `ipconfig` y usa:

```text
http://IP-DE-TU-PC:8000
```

Permite el puerto 8000 en el Firewall de Windows si los celulares no pueden conectarse. Para usarlo desde Internet se necesita desplegarlo en un servidor con dominio y HTTPS; `artisan serve` es para desarrollo, no para producción.

## Acceso inicial

- **Correo:** `docente@aula.test`
- **Contraseña:** `AulaQuiz2026!`

Cambia la contraseña antes de exponer la plataforma a una red no confiable o a Internet.

## Flujo de uso

1. Ingresa como docente.
2. Abre el cuestionario inicial o crea uno nuevo.
3. Edita las preguntas y alternativas cuando lo necesites.
4. En la biblioteca, selecciona un torneo (opcional) y pulsa **Crear sala**.
5. Comparte el PIN que aparece en la pantalla del docente.
6. Los alumnos entran a `/join/PIN` desde sus celulares o computadoras.
7. Cuando estén listos, el docente pulsa **Iniciar partida**.
8. El sistema avanza las preguntas, registra respuestas y actualiza la clasificación.

## Estructura del proyecto

- `app/Http/Controllers/`: autenticación, cuestionarios, torneos y lógica de partidas.
- `app/Models/`: modelos Eloquent.
- `database/aula_quiz_live_unico.sql`: único archivo SQL de instalación.
- `database/migrations/`: esquema Laravel equivalente para mantenimiento y futuras actualizaciones.
- `database/seeders/`: banco inicial de preguntas para futuras instalaciones mediante seeding.
- `resources/views/`: vistas Blade.
- `public/css/`: estilos.
- `public/js/`: interacción de docente, constructor y participantes.
- `install_laragon.bat`: instalación de dependencias y preparación del entorno.
- `start_laragon.bat`: inicio del servidor local.

## Importante: no mezclar métodos de instalación

Para esta entrega, utiliza el SQL único de phpMyAdmin. **No ejecutes `php artisan migrate --seed` después de importar el SQL**, porque el SQL ya crea las tablas y carga los datos iniciales. Las migraciones quedan incluidas en el código para futuras versiones y cambios controlados.

## Alcance y siguientes mejoras

Esta entrega es una primera versión funcional tipo MVP. Los torneos permiten crear y asociar partidas, pero aún no tienen fases eliminatorias, clasificación acumulada entre varias rondas ni modo por equipos. Tampoco se incluye autenticación individual de alumnos: los participantes ingresan con apodo y PIN. Para evaluaciones formales conviene añadir matrícula/cuenta de alumno, límites de intentos y controles de supervisión.

La puntuación y el orden de llegada se calculan en el servidor, no en el navegador. Aun así, antes de usarlo en producción se recomienda implementar HTTPS, protección contra intentos repetidos de PIN, copias de seguridad, políticas de privacidad, pruebas de carga y un servidor de aplicaciones adecuado. Para cientos o miles de participantes simultáneos conviene migrar el polling a Laravel Reverb/WebSockets y añadir Redis.

## Solución del error `bootstrap/cache`

El paquete ya incluye `bootstrap/cache` y las carpetas de `storage`. Si Laravel vuelve a mostrar que una carpeta debe existir y ser escribible, ejecuta desde la raíz:

```bat
mkdir bootstrap\cache
mkdir storage\framework\cache\data
mkdir storage\framework\sessions
mkdir storage\framework\views
mkdir storage\logs
php artisan optimize:clear
```

En Windows, verifica que tu usuario tenga permisos de escritura sobre esas carpetas.


## Gestión de participantes

En el panel docente abre **Participantes** para registrar alumnos con:

- Código único por docente (por ejemplo, `ALU-001`).
- Nombre completo.
- Correo electrónico opcional.
- Curso o sección opcional.

En la pantalla de ingreso a una partida, el alumno puede escribir su código. El sistema recupera el nombre del padrón y vincula ese registro a la participación de esa partida. Si no está registrado, puede entrar como invitado con un apodo.

### Si ya habías instalado la versión anterior

No vuelvas a importar el SQL completo porque ese archivo reinicia las tablas y sus datos. Reemplaza los archivos del proyecto con esta versión y ejecuta desde la terminal:

```bat
cd C:\laragon\www\kahoot
php artisan migrate
php artisan optimize:clear
```

La nueva migración crea el padrón y agrega la relación opcional a la tabla de participantes sin borrar los cuestionarios ni las partidas existentes.

### Si es una instalación desde cero

Importa el SQL único incluido en `database/aula_quiz_live_unico.sql`. No ejecutes además `php artisan migrate:fresh` ni vuelvas a importar ese SQL después de comenzar a guardar datos.
